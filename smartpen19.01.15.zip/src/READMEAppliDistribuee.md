SmartPen : Appli distribuée
========
Arnaud Bonetti
Oumayma Bounou
Fatimata Fall