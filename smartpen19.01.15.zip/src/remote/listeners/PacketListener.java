
package remote.listeners;
import java.util.ArrayList;
import remote.Packet;

/**
 *
 * @author arnaud
 */
public interface PacketListener {
    public void packetReceived(Packet packet);
}
