
package shape;

import view.Bitmap;
import view.Point;

/*
 */
public class ShapeProcessor {
    public static Bitmap compareToModel(Bitmap image, Bitmap model) {
        
        return null;
    }
    /* find the cap (a coloured spot) in the sheet
     * @param image the straightened image of the sheet
     * @return      a Point with coordinates expressed RELATIVELY to the size of the sheet : 
     *         for x, 0 is left border and 1 right border; for y, 0 is upper border and 1 is lower border
     */
    public static Point findCap(Bitmap image) {
        System.out.println("SheetProcessor : search a cap above the sheet");
        return null;
    }
}
