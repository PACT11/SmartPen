
package view;

/*
 * A object that represents a geometric transformation of the sheet
 */
public class Transformation {
    
}
