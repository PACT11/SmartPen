
package view;

/* DEBUG OBJECT, to be removed when running on Android !
 */
public class Bitmap {
    
}
