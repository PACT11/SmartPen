
package view;

/*
 */
public class Point {
    public double x;
    public double y;
}
